import { useChannel } from "@ably-labs/react-hooks";

export default function ChatWindow({ friendCode }) {
  const { channel, messages } = useChannel(`chat-${friendCode}`);

  function sendMessage(text) {
    channel.publish('chat', { text });
  }

  return (
    <div>
      <ul>
        {messages.map(msg => <li key={msg.id}>{msg.data.text}</li>)}
      </ul>
      <input onKeyDown={e => { if (e.key === "Enter") sendMessage(e.target.value) }} />
    </div>
  );
}